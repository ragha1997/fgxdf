--<exception_name>EXCEPTION;

DECLARE 
invalid_quantity EXCEPTION;
I_order_qty NUMBER:=-2;
BEGIN
IF I_order_qty<0 THEN
RAISE invalid_quantity;
END IF;
EXCEPTION
WHEN Invalid_quantity THEN
DBMS_OUTPUT.PUT_LINE('Invalid Quantity');
DBMS_OUTPUT.PUT_LINE('SQLCODE:'||SQLCODE);
DBMS_OUTPUT.PUT_LINE('SQLERRM:'||SQLERRM);
END;
