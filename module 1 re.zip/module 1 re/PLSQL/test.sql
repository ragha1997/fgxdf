DECLARE
--Declare a number
I_var number(1);

BEGIN
I_var :=15;
DBMS_OUTPUT.PUT_LINE('Value of local variable:'||I_var);

EXCEPTION                           --optional
WHEN OTHERS THEN
DBMS_OUTPUT.PUT_LINE('SQL CODE'|| SQLCODE);
DBMS_OUTPUT.PUT_LINE('E RROR MESSAGE'|| SQLERRM);

raise;

END;